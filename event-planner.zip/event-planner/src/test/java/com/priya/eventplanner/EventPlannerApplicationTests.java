package com.priya.eventplanner.event_planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
