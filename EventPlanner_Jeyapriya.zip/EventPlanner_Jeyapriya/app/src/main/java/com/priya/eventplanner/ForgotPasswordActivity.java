package com.priya.eventplanner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextAnswer;
    private Spinner spinnerSecurityQuestion;
    private Button buttonSubmit;
    private TextView textViewBackToLogin;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        // Initialize Views
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextAnswer = findViewById(R.id.editTextAnswer);
        spinnerSecurityQuestion = findViewById(R.id.spinnerSecurityQuestion);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewBackToLogin = findViewById(R.id.textViewBackToLogin);

        // Initialize Database Helper
        databaseHelper = new DatabaseHelper(this);

        // Handle Submit Button Click
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String answer = editTextAnswer.getText().toString().trim();
                String securityQuestion = spinnerSecurityQuestion.getSelectedItem().toString();

                if (username.isEmpty() || answer.isEmpty()) {
                    Toast.makeText(ForgotPasswordActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }  else {
                    // Check if the answer to the security question is correct
                    if (databaseHelper.checkSecurityAnswer(username, securityQuestion, answer)) {
                        // Redirect to Reset Password page
                        Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                        finish();  // Close the current activity
                    } else {
                        // Show error message
                        Toast.makeText(ForgotPasswordActivity.this, "Incorrect Security Answer", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Handle Back to Login Link Click
        textViewBackToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
