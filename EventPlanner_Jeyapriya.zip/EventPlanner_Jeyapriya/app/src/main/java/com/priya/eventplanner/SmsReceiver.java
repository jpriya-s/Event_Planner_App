package com.priya.eventplanner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String eventName = intent.getStringExtra("eventName");
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        String phoneNumber = dbHelper.getPhoneNumber(); // Get phone number from SMS settings

        if (phoneNumber != null) {
            String message = "Reminder: The event " + eventName + " is starting soon!";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS sent successfully", Toast.LENGTH_SHORT).show();
        }
    }
}
