package com.priya.eventplanner;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EventDetailsActivity extends AppCompatActivity {
    private EditText editTextEventName;
    private EditText editTextDescription;
    private EditText editTextStartTime;
    private EditText editTextEndTime;
    private CheckBox checkBoxSmsNotification;
    private Spinner spinnerNotificationTime;
    private Button buttonSaveEvent, buttonDeleteEvent;
    private DatabaseHelper dbHelper;
    private Event event;
    private int eventId;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);

        editTextEventName = findViewById(R.id.editTextEventName);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextStartTime = findViewById(R.id.editTextStartTime);
        editTextEndTime = findViewById(R.id.editTextEndTime);
        checkBoxSmsNotification = findViewById(R.id.checkBoxSmsNotification);
        spinnerNotificationTime = findViewById(R.id.spinnerNotificationTime);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        buttonDeleteEvent = findViewById(R.id.btnDeleteEvent);
        dbHelper = new DatabaseHelper(this);

        // Get event ID from intent if editing
        eventId = getIntent().getIntExtra("EVENT_ID", -1);
        if (eventId != -1) {
            event = dbHelper.getEventById(eventId);
            if (event != null) {
                populateEventDetails(event);
            }
        }

        // Set save button listener
        buttonSaveEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEvent();
            }
        });

        // Set delete button listener
        buttonDeleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteEvent();
            }
        });

    }

    private void populateEventDetails(Event event) {
        editTextEventName.setText(event.getName());
        editTextDescription.setText(event.getDescription());
        editTextStartTime.setText(event.getStartTime());
        editTextEndTime.setText(event.getEndTime());
        checkBoxSmsNotification.setChecked(event.isSmsNotification());
    }

    private void saveEvent() {
        String name = editTextEventName.getText().toString();
        String description = editTextDescription.getText().toString();
        String startTime = editTextStartTime.getText().toString();
        String endTime = editTextEndTime.getText().toString();
        boolean smsNotification = checkBoxSmsNotification.isChecked();
        String notificationTimeString = spinnerNotificationTime.getSelectedItem().toString();

        int notificationTime = Integer.parseInt(spinnerNotificationTime.getSelectedItem().toString());

        if (event == null) {
            dbHelper.insertEvent(name, description, startTime, endTime, smsNotification, notificationTimeString);
            scheduleSmsNotification(notificationTime, name, startTime); // Pass notification time and start time
            Toast.makeText(this, "Event Created", Toast.LENGTH_SHORT).show();
        } else {
            dbHelper.updateEvent(event.getId(), name, description, startTime, endTime, smsNotification, notificationTimeString);
            Toast.makeText(this, "Event Updated", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    // Delete the event
    private void deleteEvent() {
        if (eventId != -1) {
            dbHelper.deleteEvent(eventId);
            finish(); // Go back to events home
        }
    }

    private void scheduleSmsNotification(int notificationTime, String eventName, String startTime) {
        long eventStartTimeInMillis = getEventStartTimeInMillis(startTime); // Convert start time to milliseconds
        long notificationTimeInMillis = eventStartTimeInMillis - notificationTime * 60 * 1000; // Convert minutes to milliseconds

        Intent intent = new Intent(this, SmsReceiver.class);
        intent.putExtra("eventName", eventName); // Pass the event name to the receiver
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, eventId, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, notificationTimeInMillis, pendingIntent);
        }
    }

    private long getEventStartTimeInMillis(String startTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        try {
            Date date = sdf.parse(startTime);
            if (date != null) {
                return date.getTime();
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return -1; // Return an invalid value if parsing fails
    }
}

