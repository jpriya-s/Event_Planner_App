package com.priya.eventplanner;

public class Event {
    private int id;
    private String name;
    private String description;
    private String startTime;
    private String endTime;
    private boolean smsNotification;
    private String notificationTime;

    public Event(int id, String name, String description, String startTime, String endTime, boolean smsNotification, String notificationTime) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startTime = startTime;
        this.endTime = endTime;
        this.smsNotification = smsNotification;
        this.notificationTime = notificationTime;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public boolean isSmsNotification() { return smsNotification; }
    public String getNotificationTime() { return notificationTime; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setDescription(String description) { this.description = description; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
    public void setSmsNotification(boolean smsNotification) { this.smsNotification = smsNotification; }
    public void setNotificationTime(String notificationTime) { this.notificationTime = notificationTime; }
}
