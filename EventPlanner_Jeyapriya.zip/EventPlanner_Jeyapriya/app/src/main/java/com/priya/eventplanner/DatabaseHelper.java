package com.priya.eventplanner;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_planner.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USER = "user_details";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_FIRSTNAME = "firstname";
    private static final String COLUMN_LASTNAME = "lastname";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_SECURITY_QUESTION = "security_question";
    private static final String COLUMN_ANSWER = "answer";

    // Event Table
    private static final String TABLE_EVENT = "event";
    private static final String COLUMN_EVENT_ID = "event_id";
    private static final String COLUMN_EVENT_NAME = "event_name";
    private static final String COLUMN_EVENT_DESCRIPTION = "event_description";
    private static final String COLUMN_EVENT_START_TIME = "event_start_time";
    private static final String COLUMN_EVENT_END_TIME = "event_end_time";
    private static final String COLUMN_EVENT_SMS_NOTIFICATION = "event_sms_notification";
    private static final String COLUMN_EVENT_NOTIFICATION_TIME = "event_notification_time";

    private static final String TABLE_SMS_SETTINGS = "sms_settings";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_ENABLE_SMS_NOTIFICATION = "enable_sms_notification";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create userdetails table
        String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_FIRSTNAME + " TEXT,"
                + COLUMN_LASTNAME + " TEXT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_SECURITY_QUESTION + " TEXT,"
                + COLUMN_ANSWER + " TEXT"
                + ")";
        db.execSQL(CREATE_USER_TABLE);

        // Create Event Table
        String createEventTable = "CREATE TABLE " + TABLE_EVENT + " (" +
                COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_NAME + " TEXT, " +
                COLUMN_EVENT_DESCRIPTION + " TEXT, " +
                COLUMN_EVENT_START_TIME + " TEXT, " +
                COLUMN_EVENT_END_TIME + " TEXT, " +
                COLUMN_EVENT_SMS_NOTIFICATION + " INTEGER, " +
                COLUMN_EVENT_NOTIFICATION_TIME + " TEXT)";
        db.execSQL(createEventTable);

        String createSmsSettingsTable = "CREATE TABLE " + TABLE_SMS_SETTINGS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PHONE_NUMBER + " TEXT, " +
                COLUMN_ENABLE_SMS_NOTIFICATION + " INTEGER)";
        db.execSQL(createSmsSettingsTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SMS_SETTINGS);
        onCreate(db);
    }

    // Insert user into database
    public boolean insertUser(String firstname, String lastname, String username, String password, String securityQuestion, String answer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRSTNAME, firstname);
        values.put(COLUMN_LASTNAME, lastname);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_SECURITY_QUESTION, securityQuestion);
        values.put(COLUMN_ANSWER, answer);

        long result = db.insert(TABLE_USER, null, values);
        db.close();
        return result != -1;  // return true if insertion is successful
    }

    // Check if username already exists
    public boolean checkUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=?", new String[]{username},
                null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // Validate login credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        boolean isValid = (cursor.getCount() > 0);
        cursor.close();
        return isValid;
    }

    // Check if username and security answer match
    public boolean checkSecurityAnswer(String username, String securityQuestion, String answer) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_SECURITY_QUESTION + "=? AND " + COLUMN_ANSWER + "=?",
                new String[]{username, securityQuestion, answer},
                null, null, null);

        boolean isValid = (cursor.getCount() > 0);
        cursor.close();
        return isValid;
    }

    // Update the password for a user
    public boolean updatePassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);

        int result = db.update(TABLE_USER, values, COLUMN_USERNAME + "=?", new String[]{username});
        db.close();
        return result > 0;
    }

    // Insert new event
    public long insertEvent(String name, String description, String startTime, String endTime, boolean smsNotification, String notificationTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, name);
        values.put(COLUMN_EVENT_DESCRIPTION, description);
        values.put(COLUMN_EVENT_START_TIME, startTime);
        values.put(COLUMN_EVENT_END_TIME, endTime);
        values.put(COLUMN_EVENT_SMS_NOTIFICATION, smsNotification ? 1 : 0);
        values.put(COLUMN_EVENT_NOTIFICATION_TIME, notificationTime);
        long id = db.insert(TABLE_EVENT, null, values);
        db.close();
        return id;
    }

    // Get event by id
    public Event getEventById(int eventId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENT, null, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") Event event = new Event(
                    cursor.getInt(cursor.getColumnIndex(COLUMN_EVENT_ID)), // Check COLUMN_EVENT_ID here
                    cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NAME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DESCRIPTION)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_START_TIME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_END_TIME)),
                    cursor.getInt(cursor.getColumnIndex(COLUMN_EVENT_SMS_NOTIFICATION)) > 0,
                    cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NOTIFICATION_TIME))
            );
            cursor.close();
            return event;
        }
        return null; // Return null if cursor is empty
    }

    // Update existing event
    public boolean updateEvent(int id, String name, String description, String startTime, String endTime, boolean smsNotification, String notificationTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, name);
        values.put(COLUMN_EVENT_DESCRIPTION, description);
        values.put(COLUMN_EVENT_START_TIME, startTime);
        values.put(COLUMN_EVENT_END_TIME, endTime);
        values.put(COLUMN_EVENT_SMS_NOTIFICATION, smsNotification ? 1 : 0);
        values.put(COLUMN_EVENT_NOTIFICATION_TIME, notificationTime);
        int rowsAffected = db.update(TABLE_EVENT, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsAffected > 0;
    }

    // Method to delete an event
    public void deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d("DatabaseHelper", "eventId: "  + eventId);
        int rowsDeleted = db.delete(TABLE_EVENT, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
        Log.d("DatabaseHelper", "Rows deleted: " + rowsDeleted);
        db.close();
    }

    // Get all events
    public List<Event> getAllEvents() {
        List<Event> eventList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENT, null, null, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") Event event = new Event(
                        cursor.getInt(cursor.getColumnIndex(COLUMN_EVENT_ID)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NAME)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DESCRIPTION)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_START_TIME)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_END_TIME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN_EVENT_SMS_NOTIFICATION)) > 0,
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NOTIFICATION_TIME))
                );
                eventList.add(event);
            }
            cursor.close();
        }
        db.close();
        return eventList;
    }

    // Method to save SMS settings
    public void saveSmsSettings(String phoneNumber, boolean enableSmsNotification) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(COLUMN_ENABLE_SMS_NOTIFICATION, enableSmsNotification ? 1 : 0);

        db.insert(TABLE_SMS_SETTINGS, null, values);
        db.close();
    }

    // Method to retrieve phone number
    public String getPhoneNumber() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SMS_SETTINGS, new String[]{COLUMN_PHONE_NUMBER}, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE_NUMBER));
            cursor.close();
            return phoneNumber;
        }
        return null;
    }

    // Method to check if SMS notifications are enabled
    public boolean isSmsNotificationEnabled() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SMS_SETTINGS, new String[]{COLUMN_ENABLE_SMS_NOTIFICATION}, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") boolean isEnabled = cursor.getInt(cursor.getColumnIndex(COLUMN_ENABLE_SMS_NOTIFICATION)) > 0;
            cursor.close();
            return isEnabled;
        }
        return false;
    }

}
