package com.priya.eventplanner;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SmsSettingsActivity extends AppCompatActivity {
    private EditText etPhoneNumber;
    private CheckBox cbEnableSmsNotification;
    private Button btnSaveSettings;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        // Initialize views
        etPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        cbEnableSmsNotification = findViewById(R.id.checkBoxEnableSmsNotifications);
        btnSaveSettings = findViewById(R.id.buttonSaveSmsSettings);
        databaseHelper = new DatabaseHelper(this);

        // Load existing settings if available
        loadSettings();

        // Handle Save button click
        btnSaveSettings.setOnClickListener(v -> {
            saveSettings();
        });
    }

    // Load existing SMS settings from database (or shared preferences)
    private void loadSettings() {
        String phoneNumber = databaseHelper.getPhoneNumber();  // Modify this based on how you store settings
        boolean isSmsEnabled = databaseHelper.isSmsNotificationEnabled();

        etPhoneNumber.setText(phoneNumber);
        cbEnableSmsNotification.setChecked(isSmsEnabled);
    }

    // Save settings in the database (or shared preferences)
    private void saveSettings() {
        String phoneNumber = etPhoneNumber.getText().toString();
        boolean enableSmsNotification = cbEnableSmsNotification.isChecked();

        // Save these settings in the database
        databaseHelper.saveSmsSettings(phoneNumber, enableSmsNotification);

        // Provide feedback to the user
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }
}
