package com.priya.eventplanner;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventsHomeActivity extends AppCompatActivity  {
    private RecyclerView recyclerViewEvents;
    private EventAdapter eventAdapter;
    private List<Event> eventList;
    private DatabaseHelper dbHelper;
    private Button buttonCreateEvent;
    private TextView textViewSmsSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_home);

        buttonCreateEvent = findViewById(R.id.buttonCreateEvent);
        textViewSmsSettings = findViewById(R.id.textViewSmsSettings);

        recyclerViewEvents = findViewById(R.id.recyclerViewEvents);

        recyclerViewEvents.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);

        loadEvents();

        buttonCreateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EventsHomeActivity.this, EventDetailsActivity.class);
                startActivity(intent);
            }
        });

        // Handle click event on SMS Settings TextView
        textViewSmsSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the SMS Settings screen
                Intent intent = new Intent(EventsHomeActivity.this, SmsSettingsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload events when returning to this activity
        loadEvents();
    }

    private void loadEvents() {
        // Get all events from the database
        eventList = dbHelper.getAllEvents();

        // Log event data to verify retrieval
        for (Event event : eventList) {
            Log.d("EventsHomeActivity", "Event: " + event.getName() + " | " + event.getStartTime());
        }

        // Set up adapter for RecyclerView
        eventAdapter = new EventAdapter(this, eventList);
        recyclerViewEvents.setAdapter(eventAdapter);

        // Check if adapter is set and notify data changes
        if (eventAdapter != null) {
            eventAdapter.notifyDataSetChanged();
        }
    }

}
